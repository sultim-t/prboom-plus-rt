Plays back correctly to the end in vanilla.
Desyncs in Choco and prBoom+.
WAD and demo: http://doomedsda.us/wad1005.html